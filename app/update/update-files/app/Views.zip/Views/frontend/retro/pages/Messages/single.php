<p><?= esc($message) ?></p>

