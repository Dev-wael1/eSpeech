<?php

namespace App\Libraries;

/**
 * PayPal Library for CodeIgniter 3.x
 *
 * Library for PayPal payment gateway. It helps to integrate PayPal payment gateway
 * in the CodeIgniter application.
 *
 * It requires PayPal configuration file and it should be placed in the config directory.
 *
 * @package     CodeIgniter
 * @category    Libraries
 * @author      CodexWorld
 * @license     http://www.codexworld.com/license/
 * @link        http://www.codexworld.com
 * @version     2.0
 */

class Paypal_lib
{
    public function get_credentials()
    {
        $settings = get_settings('payment_gateways_settings', true);
       
        $data['notification_url'] = (isset($settings['notification_url'])) ? $settings['notification_url'] : 'no data';
        $data['notification_url'] = (isset($settings['notification_url'])) ? $settings['notification_url'] : 'no data';
        $data['client_id'] = (isset($settings['paypal_client_id'])) ? $settings['paypal_client_id'] : 'no data';
        $data['paypal_client_secret'] = (isset($settings['paypal_client_secret'])) ? $settings['paypal_client_secret'] : "no data";
        $data['webhook_url'] = (isset($settings['webhook_url'])) ? $settings['webhook_url'] : "no data";
        $data['webhook_id'] = (isset($settings['webhook_id'])) ? $settings['webhook_id'] : "no data";
        $data['end_point_url'] = (isset($settings['end_point_url'])) ? $settings['end_point_url'] : "no data";
        return $data;
    }
    public function generate_access_token()
    {
        $curl = curl_init();
        $cred = $this->get_credentials();
        $client_id = $cred['client_id'];
        $client_secret = $cred['paypal_client_secret'];
       
        // $url = ($cred['paypal_mode'] == 'test') ? 'https://api-m.sandbox.paypal.com/v1/oauth2/token' : 'https://api-m.paypal.com/v1/oauth2/token' ;
        $url = $cred['end_point_url'].'v1/oauth2/token';

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Basic '.base64_encode( $client_id .":". $client_secret)
            ),
        ));
        $result = curl_exec($curl);

        $response = (!empty($result)) ? json_decode($result, true) : "";
        curl_close($curl);
        $access_token = (isset($response['access_token'])) ? $response['access_token'] : "";
        return $access_token;
    }
    public function cUrl($captured_id)
    {
       
        $cred = $this->get_credentials();
        // $url = ($cred['paypal_mode'] == 'test') ? 'https://api-m.sandbox.paypal.com/v2/payments/captures/' : 'https://api-m.paypal.com/v2/payments/captures/' ;
        $url = $cred['end_point_url'].'v2/payments/captures/';

        // this may change
        $access_token = $this->generate_access_token();
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url . $captured_id,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                "Authorization: Bearer $access_token",
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
    public function fetch_transaction($captured_id){
        $data  = $this->cUrl($captured_id);
        return $data;
    }
}
