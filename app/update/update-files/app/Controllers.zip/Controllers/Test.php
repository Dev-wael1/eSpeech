<?php

namespace App\Controllers;

use App\Libraries\Aws;
use App\Libraries\Azure;
use App\Libraries\Google;
use App\Libraries\JWT;
use App\Libraries\IBM;
use App\Models\Tts_model;
use Config\Email;
use App\Libraries\Paypal_lib;
use App\Libraries\Razorpay;


class Test extends BaseController
{


    public function generate_token()
    {
        helper('function');
        generate_token();
    }
    public function index()
    {
        echo \CodeIgniter\CodeIgniter::CI_VERSION;
        // $data = fetch_details('users', ['id' => '1'])[0];
        // send_mail_with_template('subscription', $data);
    }
    public function voices()
    {
        $validation =  \Config\Services::validation();
        $request = \Config\Services::request();
        helper('function');
        $validation->setRules(
            [
                'language' => 'required'
            ],
            [
                'language' => [
                    'required' => 'Language code is required',
                ]
            ]
        );
        if (!$validation->withRequest($this->request)->run()) {
            $errors = $validation->getErrors();
            $response = [
                'error' => true,
                'message' => $errors,
                'data' => [],
                'csrfName' => csrf_token(),
                'csrfHash' => csrf_hash()
            ];

            return print_r(json_encode($response));
        }
        $voices = get_voices($request->getPost('language'));

        $response = [
            'error' => false,
            'message' => '',
            'data' => $voices,
            'csrfName' => csrf_token(),
            'csrfHash' => csrf_hash()
        ];
        return print_r(json_encode($response));
    }
    public function synthesize()
    {
        helper('function');
        $validation =  \Config\Services::validation();
        $request = \Config\Services::request();
        $validation->setRules(
            [
                'provider' => 'required',
                'voice' => 'required',
                'text' => 'required',
            ],
            [
                'provider' => [
                    'required' => 'provider is required',
                ],
                'voice' => [
                    'required' => 'voice is required',
                ],
                'text' => [
                    'required' => 'text is required',
                ],
            ]
        );
        if (!$validation->withRequest($this->request)->run()) {
            $errors = $validation->getErrors();
            $response = [
                'error' => true,
                'message' => $errors,
                'data' => []
            ];

            return print_r(json_encode($response));
        }
        $provider = strtolower($request->getPost('provider'));
        $voice = $request->getPost('voice');
        $text = $request->getPost('text');
        $language = $request->getPost('language');
        if ($provider == "ibm") {
            $ibm = new IBM;
            $base64 =  $ibm->synthesize($voice, $text, true);
        } elseif ($provider == "aws") {
            $aws = new Aws;
            $base64 =  $aws->systhesize($voice, $text, $language, true);
        } elseif ($provider == "azure") {
            $azure = new Azure;
            $base64 = $azure->systhesize($language, $voice, $text);
        } elseif ($provider == "google") {
            $google = new Google;
            $base64 = $google->systhesize($language, $voice, $text);
        } else {
            $response = [
                'error' => true,
                'message' => "Provider is not valid",
                'data' => []
            ];
            return print_r(json_encode($response));
        }
        $response = [
            'error' => false,
            'message' => '',
            'data' => $base64,
            'csrfName' => csrf_token(),
            'csrfHash' => csrf_hash()
        ];
        return print_r(json_encode($response));
    }

    public function update_all_providers()
    {
        // to update all the providers
    $test = update_all_providers();
        print_r($test);
        return print_r('something went wrong');
    }
    function test()
    {
        helper('filesystem');
        delete_files('public/uploads/images/about.png');
    }
    public function test_azure()
    {
        $azure = new Azure;
        echo "<pre>";
        return print_r($azure->get_token());
    }
    public function send_mail()
    {

        $email_config = array(
            'charset' => 'utf-8',
            'mailType' => 'html'
        );

        $email = \Config\Services::email();
        $email->initialize($email_config);

        $email->setTo("jaysspspsp@gmail.com");
        $email->setSubject("Test message");
        $email->setMessage("Hello");

        if ($email->send()) {
            echo "Email sent!";
        } else {
            echo $email->printDebugger();
            return false;
        }
    }
    public function ibm()
    {
        $ibm = new IBM;
        echo $ibm->synthesize('de-DE_BirgitV2Voice', "hello");
    }
}
