<!-- ======= Footer ======= -->
<?php
$data = [];
try {
    $data = get_settings('general_settings', true);
    $get_scripts = get_settings('scripts', true);
    $social_links = fetch_details('social_links');
} catch (Exception $e) {
    echo "<script>console.log('$e')</script>";
}
isset($data['phone']) && $data['phone'] != "" ?  $phone = $data['phone'] : $phone =  '+919999999999';
isset($data['support_email']) && $data['support_email'] != "" ?  $email = $data['support_email'] : $email =  'admin@admin.com';
?>
<footer id="footer" class="footer">
    <div class="footer-top">

        <div class="container">
            <div class="row gy-4">
              
                <div class="container">
                    <div class="copyright">
                        <?= (isset($data['copyright_details']) && $data['copyright_details'] != "") ? $data['copyright_details']  : "espeech copyright" ?>
                    </div>
                </div>
                <script>
                </script>
</footer>
<!-- End Footer -->
<a href="#"
    class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script
    src="<?= base_url('public/frontend/retro/vendor/bootstrap/js/bootstrap.bundle.js') ?>">
</script>
<script src="<?= base_url('public/frontend/retro/vendor/aos/aos.js') ?>">
</script>
<script src="<?= base_url('public/frontend/retro/vendor/lottie/lottie.js') ?>">
</script>
<script
    src="<?= base_url('public/frontend/retro/vendor/swiper/swiper-bundle.min.js') ?>">
</script>
<script src="<?= base_url('public/backend/assets/js/vendor/select2.min.js') ?>">
</script>
<script
    src="<?= base_url('public/backend/assets/js/vendor/iziToast.min.js') ?>">
</script>

<?= isset($get_scripts['footer_script']) ? $get_scripts['footer_script'] : '' ?>


<!-- Template Main JS File -->
<script src="<?= base_url('/public/frontend/retro/js/main.js') ?>"></script>