<!-- Start Section -->
<section id="error" class='un_auth'>
    <div class="container" data-aos="fade-up">
        <div class='row'>
            <div class='col-12 text-center'>
                <img src="<?= base_url('public/frontend/retro/img/401.svg') ?>" alt="Unauthorized access" title="Unauthorized access" />
            </div>
        </div>
        <div class='row'>
            <div class="col-md  d-flex text-align-center justify-content-center">
                <h1 class="errortext">Unauthorised Access.</h1>
            </div>
        </div>
    </div>
</section>
<!-- End Section -->