<section class="breadcrumbs">
    <div class="container">
        <ol class='floatc-right'>
            <li><a href="<?= base_url() ?>">Home</a></li>
            <li>About Us</li>
        </ol>
    </div>
</section>
<section class="py-5 mt-4 bg-white text-dark">
    <div class="text-center">
        <h1>About us</h1>
    </div>
    <div class="container">
        <div class="text-justify">
            <p><?= $text ?></p>
        </div>
    </div>
</section>